"""Utility helpers for Campus Companion."""

