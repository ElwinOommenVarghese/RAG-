"""
Settings and About view: Configure RAG defaults, set session Groq API key,
and review project architecture & fictional dataset notice.
"""

import os
import streamlit as st
import config


def render_settings_about():
    st.markdown("## ⚙️ Settings & About")
    st.caption("Configure default chunking, retrieval, and Groq API settings.")

    with st.container(border=True):
        st.markdown("### 🎛️ RAG Pipeline Configuration")
        c1, c2 = st.columns(2)
        with c1:
            chunk_size = st.number_input(
                "Default Chunk Size (characters)",
                min_value=100,
                max_value=2500,
                value=st.session_state.get("chunk_size", config.DEFAULT_CHUNK_SIZE),
                step=50,
            )
            top_k = st.slider(
                "Default Top-K Retrieval",
                min_value=1,
                max_value=10,
                value=st.session_state.get("top_k", config.DEFAULT_TOP_K),
            )
        with c2:
            chunk_overlap = st.number_input(
                "Default Chunk Overlap (characters)",
                min_value=0,
                max_value=500,
                value=st.session_state.get("chunk_overlap", config.DEFAULT_CHUNK_OVERLAP),
                step=25,
            )
            sim_threshold = st.slider(
                "Minimum Similarity Threshold",
                min_value=0.0,
                max_value=0.9,
                value=st.session_state.get("similarity_threshold", config.DEFAULT_SIMILARITY_THRESHOLD),
                step=0.05,
            )

        if st.button("💾 Save RAG Settings", type="primary"):
            st.session_state.chunk_size = int(chunk_size)
            st.session_state.chunk_overlap = int(chunk_overlap)
            st.session_state.top_k = int(top_k)
            st.session_state.similarity_threshold = float(sim_threshold)
            st.success("RAG settings saved for this session! (Reprocess existing docs in Knowledge Base to apply new chunk sizes.)")

    with st.container(border=True):
        st.markdown("### 🔑 Groq API Key Configuration")
        current_key = config.get_groq_api_key()
        if current_key:
            st.success(f"Groq API key is active (Model: `{config.get_groq_model()}`).")
        else:
            st.warning("No Groq API key detected. Add `GROQ_API_KEY` to `.env` or enter it below for this session.")

        entered_key = st.text_input(
            "Session Groq API Key (not saved to disk):",
            type="password",
            placeholder="gsk_...",
        )
        model_choice = st.selectbox(
            "Groq Model",
            ["openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.8-27b", "llama-3.1-8b-instant"],
            index=0,
        )
        if st.button("⚡ Apply Groq Settings"):
            if entered_key.strip():
                os.environ["GROQ_API_KEY"] = entered_key.strip()
            os.environ["GROQ_MODEL"] = model_choice
            st.success("Groq configuration updated for this session!")
            st.rerun()

    with st.container(border=True):
        st.markdown("### ℹ️ About Campus Companion – Interactive RAG Learning Lab")
        st.markdown(
            """
            **Campus Companion** is an educational Retrieval-Augmented Generation (RAG) lab built with:
            - **Frontend:** Streamlit
            - **PDF Extraction:** PyMuPDF (`fitz`)
            - **Chunking:** LangChain `RecursiveCharacterTextSplitter`
            - **Embeddings:** Sentence Transformers (`all-MiniLM-L6-v2`)
            - **Vector Database:** ChromaDB (local persistent storage)
            - **LLM Generation:** Groq API

            > **Fictional Policy Notice:** All included sample documents belong to *Horizon Crest University (Fictional)*
            > and are strictly for educational RAG demonstration. Never treat sample policies as real university rules.
            """
        )

