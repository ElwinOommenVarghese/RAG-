"""
Dashboard view: RAG system metrics, interactive architecture diagram,
sample dataset loader, and activity history.
"""

import streamlit as st
import config
from rag import vector_store, pipeline
from utils import helpers


ARCH_STAGES = [
    (
        "1. Documents",
        "📄",
        "Raw educational files (PDF or TXT) such as attendance policies, exam rules, and library guidelines. "
        "These are the source of truth that the AI will rely on instead of guessing.",
    ),
    (
        "2. Text Extraction",
        "🔍",
        "PyMuPDF reads every page of a PDF (or UTF-8 reader for TXT) and extracts clean plain text, "
        "removing noisy whitespace while keeping paragraph structure.",
    ),
    (
        "3. Chunking",
        "✂️",
        "Long documents are split into smaller overlapping pieces (default: 500 characters, 100 overlap) "
        "using LangChain's RecursiveCharacterTextSplitter so retrieval stays focused and accurate.",
    ),
    (
        "4. Embeddings",
        "🧬",
        "Each chunk is converted into a 384-dimensional numerical vector using `all-MiniLM-L6-v2` "
        "(Sentence Transformers). Similar meanings produce nearby vectors.",
    ),
    (
        "5. Vector Database",
        "🗄️",
        "ChromaDB stores each vector along with its original text and source metadata on disk, "
        "allowing fast semantic similarity search.",
    ),
    (
        "6. Retrieval",
        "🎯",
        "When you ask a question, your question is embedded with the same model and compared against "
        "ChromaDB to fetch the Top-K most semantically similar chunks.",
    ),
    (
        "7. LLM",
        "🤖",
        "The retrieved chunks are injected into a prompt (Augmentation) and sent to the Groq LLM, "
        "instructed to answer strictly from the retrieved context.",
    ),
    (
        "8. Answer",
        "✅",
        "You receive a clear, grounded answer with source document citations — and you can inspect "
        "every intermediate stage in the RAG Pipeline Explorer!",
    ),
]


def render_dashboard():
    st.markdown("## 🏠 Campus Companion — RAG System Dashboard")
    st.caption(
        "Monitor your Knowledge Base, explore the 8-stage RAG architecture, and track recent activity."
    )

    registry = helpers.load_registry()
    activity = helpers.load_activity_log()
    db_health = vector_store.health_check()
    groq_ok = bool(config.get_groq_api_key())

    total_docs = len(registry)
    total_pages = sum(d.get("page_count", 0) for d in registry)
    total_chunks = sum(d.get("chunk_count", 0) for d in registry)
    total_vectors = db_health.get("vector_count", 0)
    questions_asked = sum(1 for a in activity if a.get("type") == "question")

    # First-launch Sample Dataset Loader
    if total_docs == 0:
        st.info(
            "👋 **Welcome to Campus Companion!** Your Knowledge Base is currently empty. "
            "Load the 5 fictional sample university documents (Attendance, Exams, Internships, Library, FAQs) "
            "to test the complete RAG pipeline right away.",
            icon="🚀",
        )
        if st.button("📥 Load 5 Sample Fictional Documents", type="primary"):
            with st.spinner("Running 5-step ingestion pipeline on sample documents..."):
                reports = pipeline.load_sample_documents(
                    chunk_size=st.session_state.get("chunk_size", config.DEFAULT_CHUNK_SIZE),
                    chunk_overlap=st.session_state.get("chunk_overlap", config.DEFAULT_CHUNK_OVERLAP),
                )
            st.success(f"Successfully ingested {len(reports)} sample documents into ChromaDB!")
            st.rerun()

    # Top KPI Metrics
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Uploaded Docs", total_docs)
    c2.metric("Extracted Pages", total_pages)
    c3.metric("Chunks Created", total_chunks)
    c4.metric("Vectors Stored", total_vectors)
    c5.metric("Questions Asked", questions_asked)

    st.markdown("")
    s1, s2 = st.columns(2)
    with s1:
        st.markdown(
            f"""
            <div class="cc-card">
                <div class="cc-card-title">🗄️ Vector Database (ChromaDB)</div>
                <div style="font-size:1.05rem;font-weight:700;color:{'#34d399' if db_health['ok'] else '#f87171'};">
                    {db_health['status']} — {total_vectors} embeddings indexed
                </div>
                <div class="cc-muted">Persistent local storage at <code>data/chroma_db</code></div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s2:
        st.markdown(
            f"""
            <div class="cc-card">
                <div class="cc-card-title">⚡ LLM Connection (Groq API)</div>
                <div style="font-size:1.05rem;font-weight:700;color:{'#34d399' if groq_ok else '#fbbf24'};">
                    {'Connected — ' + config.get_groq_model() if groq_ok else 'Not Configured (Missing GROQ_API_KEY)'}
                </div>
                <div class="cc-muted">
                    {'Ready for grounded answer generation' if groq_ok else 'Add GROQ_API_KEY in .env or Settings to generate LLM answers'}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("---")

    # Interactive RAG Architecture Diagram
    st.markdown("### 🗺️ Interactive RAG Architecture Diagram")
    st.caption("Click any stage below to see what happens inside that step of the pipeline.")

    if "selected_arch_stage" not in st.session_state:
        st.session_state.selected_arch_stage = 0

    cols = st.columns(4)
    for idx, (label, icon, _) in enumerate(ARCH_STAGES):
        with cols[idx % 4]:
            btn_type = "primary" if st.session_state.selected_arch_stage == idx else "secondary"
            if st.button(f"{icon} {label}", key=f"arch_{idx}", use_container_width=True, type=btn_type):
                st.session_state.selected_arch_stage = idx

    sel_label, sel_icon, sel_desc = ARCH_STAGES[st.session_state.selected_arch_stage]
    st.markdown(
        f"""
        <div class="cc-card" style="border-left: 4px solid #8b5cf6; margin-top: 8px;">
            <div style="font-size:1.05rem;font-weight:700;">{sel_icon} {sel_label}</div>
            <div style="margin-top:6px;color:#cbd5e1;">{sel_desc}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("---")

    # Recent Activity History
    st.markdown("### 🕒 Recent Activity History")
    if not activity:
        st.caption("No activity recorded yet. Upload a document or ask a question to begin!")
    else:
        for item in activity[:12]:
            icon = "📄" if item["type"] == "upload" else "🗑️" if item["type"] == "delete" else "💬"
            st.markdown(
                f"- `{item['timestamp']}` {icon} {item['description']}"
            )

