"""
Sidebar navigation and live system status indicators.
"""

import streamlit as st
import config
from rag import vector_store
from utils import helpers


NAV_PAGES = [
    "🏠 Dashboard",
    "📚 Knowledge Base",
    "💬 Ask Campus Companion",
    "🔬 RAG Pipeline Explorer",
    "🧪 RAG Experiments",
    "🎓 Learning Centre",
    "⚙️ Settings & About",
]


def render_sidebar() -> str:
    """Render sidebar navigation, live DB/LLM badges, and quick stats."""
    with st.sidebar:
        st.markdown(
            """
            <div style="padding: 8px 0 16px 0;">
                <div style="font-size: 1.35rem; font-weight: 800; background: linear-gradient(90deg, #a78bfa, #38bdf8); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                    🎓 Campus Companion
                </div>
                <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 2px;">
                    Interactive RAG Learning Lab
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        # Allow programmatic page navigation (e.g., "Explore How This Answer Was Generated")
        if "nav_page" not in st.session_state:
            st.session_state.nav_page = NAV_PAGES[0]

        selected = st.radio(
            "Navigation",
            NAV_PAGES,
            index=NAV_PAGES.index(st.session_state.nav_page),
            label_visibility="collapsed",
        )
        st.session_state.nav_page = selected

        st.divider()

        # Live System Status
        db_health = vector_store.health_check()
        groq_ok = bool(config.get_groq_api_key())
        docs_count = len(helpers.load_registry())

        st.markdown("**System Status**")
        if db_health["ok"]:
            st.success(f"ChromaDB: Connected ({db_health['vector_count']} vectors)", icon="🟢")
        else:
            st.error(f"ChromaDB: {db_health['status']}", icon="🔴")

        if groq_ok:
            st.success(f"Groq LLM: Ready ({config.get_groq_model()})", icon="⚡")
        else:
            st.warning("Groq API Key: Missing (.env)", icon="🟡")

        st.caption(f"Indexed Documents: **{docs_count}**")
        st.caption(f"Embedding Model: `{config.EMBEDDING_MODEL_NAME}`")

        return selected

