"""
RAG Pipeline Explorer — The flagship educational feature of Campus Companion.
Visually inspects all 7 internal stages of the most recent RAG execution.
"""

import pandas as pd
import streamlit as st
import config
from rag import pipeline, vector_store


def render_pipeline_explorer():
    st.markdown("## 🔬 RAG Pipeline Explorer")
    st.caption(
        "Inspect every internal stage of how Campus Companion turned a question into a grounded answer."
    )

    # Allow running a query directly here if desired
    with st.expander("⚡ Run a New Question Directly in Explorer", expanded="latest_rag_trace" not in st.session_state):
        q_input = st.text_input(
            "Enter a question to trace through all 7 RAG stages:",
            value="What is the minimum attendance requirement?",
        )
        if st.button("🚀 Run & Inspect 7 Stages", type="primary"):
            if vector_store.get_total_vectors() == 0:
                st.warning("Please load sample documents or upload a file in **Knowledge Base** first.")
            elif not q_input.strip():
                st.warning("Please enter a question.")
            else:
                with st.spinner("Executing real 7-stage RAG pipeline..."):
                    trace = pipeline.run_rag_query(
                        question=q_input,
                        top_k=st.session_state.get("top_k", config.DEFAULT_TOP_K),
                        similarity_threshold=st.session_state.get(
                            "similarity_threshold", config.DEFAULT_SIMILARITY_THRESHOLD
                        ),
                    )
                st.session_state.latest_rag_trace = trace
                st.rerun()

    trace = st.session_state.get("latest_rag_trace")
    if not trace:
        st.info("Ask a question in **Ask Campus Companion** (or use the box above) to inspect the 7-stage trace.")
        return

    st.caption(f"Showing trace captured at `{trace['timestamp']}`")

    # ------------------------------------------------------------------
    # STAGE 1: USER QUERY
    # ------------------------------------------------------------------
    with st.container(border=True):
        st.markdown("### Stage 1: User Query")
        st.info(f"**Exact Question:** {trace['stage1_user_query']}")
        st.caption(
            "💡 **Why this matters:** The user's natural-language question is the starting point of retrieval. "
            "Unlike keyword search, RAG will convert this entire question into a semantic vector."
        )

    # ------------------------------------------------------------------
    # STAGE 2: QUERY EMBEDDING
    # ------------------------------------------------------------------
    emb = trace["stage2_query_embedding"]
    vec = emb["vector"]
    with st.container(border=True):
        st.markdown("### Stage 2: Query Embedding")
        m1, m2, m3 = st.columns(3)
        m1.metric("Embedding Model", emb["model"])
        m2.metric("Vector Dimensions", emb["dimension"])
        m3.metric("Embedding Time", f"{emb['embed_time_sec']} s")

        st.markdown("**Sample Vector Values (first 12 of 384 dimensions):**")
        sample_vals = [round(v, 5) for v in vec[:12]]
        st.code(str(sample_vals), language="python")

        st.markdown("**Visual Representation (First 40 Dimensions):**")
        df_vec = pd.DataFrame({"Dimension": list(range(1, min(41, len(vec) + 1))), "Value": vec[:40]})
        st.bar_chart(df_vec.set_index("Dimension"), height=180)

        with st.expander("🔍 View Full Vector (All Dimensions)"):
            st.json([round(v, 6) for v in vec])

        st.caption(
            "💡 **What is happening:** An embedding model converts text into a list of numbers (a vector). "
            "Questions and document chunks with similar *meaning* point in similar directions in this 384-D space."
        )

    # ------------------------------------------------------------------
    # STAGE 3: SIMILARITY SEARCH
    # ------------------------------------------------------------------
    sim_search = trace["stage3_similarity_search"]
    with st.container(border=True):
        st.markdown("### Stage 3: Similarity Search (ChromaDB)")
        s1, s2, s3 = st.columns(3)
        s1.metric("Chunks Searched", sim_search["total_chunks_searched"])
        s2.metric("Top-K Setting", sim_search["top_k"])
        s3.metric("Threshold", sim_search["similarity_threshold"])

        metric_label = sim_search.get("metric") or sim_search.get("similarity_metric", "Cosine Similarity")
        st.caption(f"**Similarity Metric:** {metric_label}")

        candidates = sim_search["candidates"]
        if not candidates:
            st.warning("No chunks found in ChromaDB.")
        else:
            rows = []
            for rank, c in enumerate(candidates, start=1):
                rows.append(
                    {
                        "Rank": rank,
                        "Document": c["metadata"].get("source", "Unknown"),
                        "Chunk #": c["metadata"].get("chunk_index", 0) + 1,
                        "Cosine Similarity": c["similarity"],
                        "Cosine Distance": c["distance"],
                        "Preview": c["text"][:100].replace("\n", " ") + "...",
                    }
                )
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

        st.warning(
            "⚠️ **Important:** Similarity and distance scores measure how close two texts are in vector space — "
            "they are **NOT** answer-confidence probabilities! A high similarity score only means the text "
            "shares related concepts or vocabulary.",
            icon="📏",
        )

    # ------------------------------------------------------------------
    # STAGE 4: RETRIEVED CONTEXT
    # ------------------------------------------------------------------
    selected = trace["stage4_retrieved_context"]
    with st.container(border=True):
        st.markdown("### Stage 4: Retrieved Context")
        if not selected:
            st.warning("No chunks passed the similarity threshold.")
        else:
            for idx, chunk in enumerate(selected, start=1):
                src = chunk["metadata"].get("source", "Unknown")
                sim = chunk["similarity"]
                st.markdown(
                    f"**Selected Chunk {idx}** — `{src}` (Similarity: `{sim:.4f}`)"
                )
                highlights = chunk.get("highlighted_sentences", [])
                if highlights:
                    st.markdown("**Relevant Sentences Detected:**")
                    for h in highlights:
                        st.markdown(f"> ✨ {h}")
                else:
                    st.caption("Selected via semantic vector proximity (even without exact keyword overlap).")

                with st.expander(f"Expand Full Chunk {idx} & Metadata"):
                    st.text(chunk["text"])
                    st.json(chunk["metadata"])

        st.caption(
            "💡 **Why these chunks:** Only the Top-K chunks that pass your similarity threshold are passed forward "
            "to keep the LLM prompt focused and within token limits."
        )

    # ------------------------------------------------------------------
    # STAGE 5: PROMPT AUGMENTATION
    # ------------------------------------------------------------------
    prompt_parts = trace["stage5_prompt_augmentation"]
    with st.container(border=True):
        st.markdown("### Stage 5: Prompt Augmentation")
        st.caption(
            "💡 **Augmentation** means injecting the retrieved context into the prompt before calling the LLM."
        )
        tab_sys, tab_ctx, tab_q, tab_full = st.tabs(
            ["1. System Instructions", "2. Retrieved Context", "3. User Question", "4. Full Prompt"]
        )
        with tab_sys:
            st.code(prompt_parts["system_instructions"], language="markdown")
        with tab_ctx:
            st.code(prompt_parts["retrieved_context"], language="markdown")
        with tab_q:
            st.code(prompt_parts["user_question"], language="markdown")
        with tab_full:
            st.code(prompt_parts["full_prompt"], language="markdown")

    # ------------------------------------------------------------------
    # STAGE 6: LLM GENERATION
    # ------------------------------------------------------------------
    gen = trace["stage6_llm_generation"]
    with st.container(border=True):
        st.markdown("### Stage 6: LLM Generation")
        g1, g2, g3 = st.columns(3)
        g1.metric("Provider", gen["provider"])
        g2.metric("Model", gen["model"])
        g3.metric("Generation Time", f"{gen['generation_time_sec']} s")

        if gen["status"] == "success":
            st.success("Generated grounded response using the supplied context:")
            st.markdown(gen["answer"])
        elif gen["status"] == "no_context":
            st.info(gen["answer"])
        else:
            st.error(gen["error_message"])

        st.caption(
            "💡 **How generation works:** The LLM reads the System Instructions + Retrieved Context and writes "
            "a clear natural-language answer without inventing external facts."
        )

    # ------------------------------------------------------------------
    # STAGE 7: FINAL ANSWER
    # ------------------------------------------------------------------
    final = trace["stage7_final_answer"]
    with st.container(border=True):
        st.markdown("### Stage 7: Final Answer & Citations")
        if final["status"] == "success":
            st.markdown(final["answer"])
        elif final["status"] == "no_context":
            st.info(final["answer"])
        else:
            st.error(final["error_message"])

        if final["sources"]:
            st.markdown("**Source Citations:** " + " · ".join(f"`{s}`" for s in final["sources"]))
        st.caption(
            "💡 **Connection to chunks:** Every claim in the final answer traces back to the chunks shown in Stage 4."
        )

