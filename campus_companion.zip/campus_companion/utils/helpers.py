"""
Persistence and formatting utilities for Campus Companion.
Manages the document registry, activity history, and file hashing.
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any
import config


def compute_sha256(data: bytes) -> str:
    """Compute SHA-256 hex digest of raw file bytes for duplicate detection."""
    return hashlib.sha256(data).hexdigest()


def format_file_size(num_bytes: int) -> str:
    """Human-readable file size."""
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1024 * 1024:
        return f"{num_bytes / 1024:.1f} KB"
    return f"{num_bytes / (1024 * 1024):.2f} MB"


def load_registry() -> List[Dict[str, Any]]:
    """Load the list of ingested documents from disk."""
    if not config.REGISTRY_PATH.exists():
        return []
    try:
        return json.loads(config.REGISTRY_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_registry(docs: List[Dict[str, Any]]) -> None:
    """Persist the document registry to disk."""
    config.REGISTRY_PATH.write_text(
        json.dumps(docs, indent=2), encoding="utf-8"
    )


def load_activity_log() -> List[Dict[str, Any]]:
    """Load recent activity history (uploads, deletions, questions)."""
    if not config.ACTIVITY_LOG_PATH.exists():
        return []
    try:
        return json.loads(config.ACTIVITY_LOG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []


def append_activity(event_type: str, description: str) -> None:
    """Append a timestamped event to the activity log (keeps latest 40)."""
    logs = load_activity_log()
    logs.insert(
        0,
        {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": event_type,
            "description": description,
        },
    )
    config.ACTIVITY_LOG_PATH.write_text(
        json.dumps(logs[:40], indent=2), encoding="utf-8"
    )

