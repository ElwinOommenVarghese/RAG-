"""
Interactive RAG Experiments view: Change Top-K, similarity threshold,
chunk size, and chunk overlap to observe real retrieval & answer differences.
"""

import streamlit as st
import config
from rag import pipeline, vector_store
from utils import helpers


def render_experiments():
    st.markdown("## 🧪 Interactive RAG Experiments")
    st.caption(
        "Tune RAG hyperparameters and run real side-by-side experiments to see how retrieval and answers change."
    )

    if vector_store.get_total_vectors() == 0:
        st.warning("Load sample documents or upload files in **Knowledge Base** before running experiments.")
        return

    # Controls
    with st.container(border=True):
        st.markdown("### 🎛️ Experiment Parameters")
        c1, c2 = st.columns(2)
        with c1:
            exp_top_k_a = st.slider("Run A — Top-K", min_value=1, max_value=10, value=1)
            exp_top_k_b = st.slider("Run B — Top-K", min_value=1, max_value=10, value=5)
        with c2:
            exp_threshold = st.slider(
                "Similarity Threshold", min_value=0.0, max_value=0.9, value=0.0, step=0.05
            )
            show_context = st.checkbox("Show Retrieved Context Chunks", value=True)

        st.markdown("---")
        st.markdown("**Optional: Test Different Chunking Settings (Reprocesses All Indexed Docs)**")
        ch1, ch2, ch3 = st.columns([1, 1, 1])
        with ch1:
            new_chunk_size = st.number_input(
                "Chunk Size (chars)", min_value=100, max_value=2500,
                value=st.session_state.get("chunk_size", config.DEFAULT_CHUNK_SIZE), step=50
            )
        with ch2:
            new_overlap = st.number_input(
                "Chunk Overlap (chars)", min_value=0, max_value=500,
                value=st.session_state.get("chunk_overlap", config.DEFAULT_CHUNK_OVERLAP), step=25
            )
        with ch3:
            st.markdown("<div style='height:26px;'></div>", unsafe_allow_html=True)
            if st.button("🔄 Apply & Reprocess Docs", use_container_width=True):
                st.session_state.chunk_size = int(new_chunk_size)
                st.session_state.chunk_overlap = int(new_overlap)
                registry = helpers.load_registry()
                with st.spinner(f"Reprocessing {len(registry)} documents..."):
                    for doc in registry:
                        pipeline.reprocess_document(
                            doc["document_id"],
                            chunk_size=int(new_chunk_size),
                            chunk_overlap=int(new_overlap),
                        )
                st.success(
                    f"Reprocessed all documents with chunk_size={new_chunk_size}, overlap={new_overlap}!"
                )
                st.rerun()

    # Side-by-Side Question Runner
    st.markdown("### ⚖️ Side-by-Side Top-K Comparison")
    question = st.text_input(
        "Question to test:",
        value="What happens if a student misses an examination and how do they apply for leave?",
    )

    if st.button("🚀 Run Real Comparison (Run A vs Run B)", type="primary"):
        with st.spinner("Executing real RAG pipeline for Run A and Run B..."):
            trace_a = pipeline.run_rag_query(
                question, top_k=exp_top_k_a, similarity_threshold=exp_threshold, log_activity=False
            )
            trace_b = pipeline.run_rag_query(
                question, top_k=exp_top_k_b, similarity_threshold=exp_threshold, log_activity=False
            )

        col_a, col_b = st.columns(2)
        for col, label, tr in [(col_a, f"Run A (Top-K = {exp_top_k_a})", trace_a), (col_b, f"Run B (Top-K = {exp_top_k_b})", trace_b)]:
            with col:
                with st.container(border=True):
                    st.markdown(f"#### {label}")
                    chunks = tr["stage4_retrieved_context"]
                    st.metric("Chunks Retrieved", len(chunks))

                    final = tr["stage7_final_answer"]
                    if final["status"] == "success":
                        st.markdown("**Generated Answer:**")
                        st.markdown(final["answer"])
                    elif final["status"] == "no_context":
                        st.info(final["answer"])
                    else:
                        st.warning(final["error_message"])

                    if final["sources"]:
                        st.caption("Sources: " + ", ".join(f"`{s}`" for s in final["sources"]))

                    if show_context and chunks:
                        with st.expander(f"View {len(chunks)} Retrieved Chunks"):
                            for i, ch in enumerate(chunks, start=1):
                                st.markdown(
                                    f"**{i}. `{ch['metadata'].get('source')}`** (sim: `{ch['similarity']:.4f}`)"
                                )
                                st.text(ch["text"])

    st.markdown("---")
    st.markdown("### 📖 5 Guided RAG Scenarios (What to Expect)")
    scenarios = [
        (
            "1. Correct Document Uploaded",
            "Ask *'What is the minimum attendance requirement?'* when `01_student_attendance_policy.txt` is indexed.",
            "High-similarity chunks from the attendance policy are retrieved, and the LLM gives an exact, cited answer (75%).",
        ),
        (
            "2. Relevant Document Missing",
            "Delete `04_library_rules.txt` in Knowledge Base (or set Similarity Threshold to `0.65`) and ask *'How many books can I borrow?'*.",
            "Either no relevant chunks pass the threshold or unrelated chunks score poorly, and the system refuses to invent a policy.",
        ),
        (
            "3. Chunk Size Too Small (e.g., 120 chars)",
            "Set Chunk Size = `120`, Overlap = `20`, click **Apply & Reprocess**, and ask a multi-part question.",
            "Sentences get cut in half! Retrieved chunks may miss surrounding conditions (like exceptions or deadlines).",
        ),
        (
            "4. Chunk Size Too Large (e.g., 1800 chars)",
            "Set Chunk Size = `1800`, Overlap = `100`, and reprocess.",
            "Each chunk packs multiple unrelated sections together, diluting the embedding vector and adding noise to the prompt.",
        ),
        (
            "5. Increasing Top-K (1 → 5)",
            "Compare Top-K = `1` vs Top-K = `5` on a cross-document question (like missing an exam + applying for leave).",
            "Top-K = 1 only sees one policy, whereas Top-K = 5 pulls chunks from both `02_examination_guidelines.txt` and `01_student_attendance_policy.txt`.",
        ),
    ]
    for title, how, impact in scenarios:
        with st.expander(title):
            st.markdown(f"**How to test:** {how}")
            st.markdown(f"**Expected impact:** {impact}")

