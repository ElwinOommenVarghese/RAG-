"""Streamlit UI components for Campus Companion."""

