"""
Ask Campus Companion view: Conversational RAG Chatbot with source citations,
expandable retrieved chunks, and 1-click navigation to the RAG Pipeline Explorer.
"""

import streamlit as st
import config
from rag import pipeline, vector_store


EXAMPLE_QUESTIONS = [
    "What is the minimum attendance requirement?",
    "What happens if a student misses an examination?",
    "What are the internship requirements?",
    "How many books can a student borrow?",
    "What is the procedure for applying for leave?",
]


def render_chat():
    st.markdown("## 💬 Ask Campus Companion")
    st.caption(
        "Ask questions about your uploaded student policies. Every answer is grounded in retrieved ChromaDB chunks."
    )

    if vector_store.get_total_vectors() == 0:
        st.warning(
            "Your Knowledge Base is empty! Go to **Dashboard** or **Knowledge Base** to upload documents "
            "or load the 5 sample fictional documents first.",
            icon="📚",
        )

    if not config.get_groq_api_key():
        st.warning(
            "⚠️ **Groq API Key Not Configured:** Retrieval (embedding + ChromaDB search) will still run, "
            "but LLM answer generation requires a `GROQ_API_KEY` in `.env` or **Settings & About**.",
            icon="🔑",
        )

    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []

    # Quick Example Question Chips
    st.markdown("**Try an example question:**")
    q_cols = st.columns(len(EXAMPLE_QUESTIONS))
    clicked_example = None
    for idx, q in enumerate(EXAMPLE_QUESTIONS):
        with q_cols[idx]:
            if st.button(q, key=f"ex_q_{idx}", use_container_width=True):
                clicked_example = q

    # Render conversation history
    for msg_idx, msg in enumerate(st.session_state.chat_messages):
        with st.chat_message(msg["role"]):
            if msg["role"] == "user":
                st.markdown(msg["content"])
            else:
                trace = msg["trace"]
                status = trace["stage7_final_answer"]["status"]
                if status == "success":
                    st.markdown(trace["stage7_final_answer"]["answer"])
                elif status == "no_context":
                    st.info(trace["stage7_final_answer"]["answer"])
                else:
                    st.error(trace["stage7_final_answer"]["error_message"])

                sources = trace["stage7_final_answer"]["sources"]
                chunks = trace["stage4_retrieved_context"]

                if sources:
                    st.caption("📚 **Sources:** " + " · ".join(f"`{s}`" for s in sources))

                col_exp, col_btn = st.columns([2, 1])
                with col_exp:
                    if chunks:
                        with st.expander(f"🔎 Inspect {len(chunks)} Retrieved Chunks"):
                            for i, ch in enumerate(chunks, start=1):
                                src = ch["metadata"].get("source", "Unknown")
                                sim = ch.get("similarity", 0.0)
                                st.markdown(
                                    f"**Chunk {i}** — `{src}` (Similarity: `{sim:.4f}`)"
                                )
                                st.text(ch["text"])
                with col_btn:
                    if st.button(
                        "🔬 Explore How This Answer Was Generated",
                        key=f"explore_btn_{msg_idx}",
                        use_container_width=True,
                    ):
                        st.session_state.latest_rag_trace = trace
                        st.session_state.nav_page = "🔬 RAG Pipeline Explorer"
                        st.rerun()

    # Chat Input
    user_input = st.chat_input("Ask a question about attendance, exams, internships, or library rules...")
    prompt_to_run = clicked_example or user_input

    if prompt_to_run:
        st.session_state.chat_messages.append({"role": "user", "content": prompt_to_run})

        top_k = st.session_state.get("top_k", config.DEFAULT_TOP_K)
        sim_threshold = st.session_state.get("similarity_threshold", config.DEFAULT_SIMILARITY_THRESHOLD)

        # Build lightweight text history for follow-ups
        history_pairs = []
        for m in st.session_state.chat_messages[:-1]:
            if m["role"] == "user":
                history_pairs.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                ans = m["trace"]["stage7_final_answer"].get("answer", "")
                if ans:
                    history_pairs.append({"role": "assistant", "content": ans})

        with st.spinner("Running 7-stage RAG pipeline (Embed → Search → Augment → Generate)..."):
            trace = pipeline.run_rag_query(
                question=prompt_to_run,
                top_k=top_k,
                similarity_threshold=sim_threshold,
                chat_history=history_pairs,
            )

        st.session_state.latest_rag_trace = trace
        st.session_state.chat_messages.append({"role": "assistant", "trace": trace})
        st.rerun()

