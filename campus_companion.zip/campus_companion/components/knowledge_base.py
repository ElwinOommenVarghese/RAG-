"""
Knowledge Base view: Document upload, 5-step ingestion progress,
processing reports, chunk inspection, reprocessing, and deletion.
"""

import streamlit as st
import config
from rag import pipeline, vector_store
from utils import helpers


def render_knowledge_base():
    st.markdown("## 📚 Knowledge Base — Document Ingestion")
    st.caption(
        "Upload PDF or TXT educational documents, watch the 5-step ingestion pipeline, and inspect stored chunks."
    )

    chunk_size = st.session_state.get("chunk_size", config.DEFAULT_CHUNK_SIZE)
    chunk_overlap = st.session_state.get("chunk_overlap", config.DEFAULT_CHUNK_OVERLAP)

    col_up, col_sample = st.columns([2, 1])
    with col_up:
        uploaded_files = st.file_uploader(
            "Upload Student Handbooks or Policy Documents (PDF or TXT)",
            type=["pdf", "txt"],
            accept_multiple_files=True,
        )
    with col_sample:
        st.markdown("<div style='height:28px;'></div>", unsafe_allow_html=True)
        if st.button("📥 Load Sample Fictional Docs", use_container_width=True):
            with st.spinner("Ingesting sample fictional documents..."):
                reports = pipeline.load_sample_documents(
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                )
            st.success(f"Loaded {len(reports)} sample documents!")
            st.rerun()

    st.caption(
        f"Active Chunking Config: **Chunk Size = {chunk_size} chars** | **Overlap = {chunk_overlap} chars** "
        "(configurable in **Settings & About** or **RAG Experiments**)."
    )

    # Process newly uploaded files with live 5-step progress
    if uploaded_files:
        if st.button("🚀 Ingest Uploaded Documents", type="primary"):
            for uf in uploaded_files:
                progress_bar = st.progress(0, text=f"Starting ingestion for {uf.name}...")
                status_box = st.empty()

                def _on_progress(step: int, msg: str):
                    progress_bar.progress(step / 5.0, text=msg)
                    status_box.info(msg)

                try:
                    report = pipeline.ingest_document(
                        file_name=uf.name,
                        file_bytes=uf.getvalue(),
                        chunk_size=chunk_size,
                        chunk_overlap=chunk_overlap,
                        progress_callback=_on_progress,
                    )
                    progress_bar.progress(1.0, text=f"Completed: {uf.name}")
                    status_box.success(f"Successfully indexed **{uf.name}**!")
                    st.session_state.last_ingestion_report = report
                except ValueError as err:
                    progress_bar.empty()
                    status_box.warning(str(err))
                except Exception as exc:
                    progress_bar.empty()
                    status_box.error(f"Ingestion failed for '{uf.name}': {exc}")

    # Show Latest Document Processing Report
    if "last_ingestion_report" in st.session_state:
        rep = st.session_state.last_ingestion_report
        with st.expander("📋 Latest Document Processing Report", expanded=True):
            r1, r2, r3, r4 = st.columns(4)
            r1.metric("Document", rep["file_name"])
            r2.metric("Pages", rep["page_count"])
            r3.metric("Extracted Chars", f"{rep['extracted_text_length']:,}")
            r4.metric("Chunks / Vectors", f"{rep['chunk_count']} / {rep['vectors_stored']}")
            st.caption(
                f"Chunk Size: `{rep['chunk_size']}` | Overlap: `{rep['chunk_overlap']}` | "
                f"Embedding Model: `{rep['embedding_model']}` ({rep['embedding_dim']} dims, {rep['embed_time_sec']}s)"
            )

    st.markdown("---")
    st.markdown("### 🗂️ Indexed Documents")

    registry = helpers.load_registry()
    if not registry:
        st.info("No documents indexed yet. Upload a PDF/TXT file or click **Load Sample Fictional Docs** above.")
        return

    for doc in registry:
        with st.container(border=True):
            top_cols = st.columns([3, 1, 1, 1])
            with top_cols[0]:
                st.markdown(f"**📄 {doc['file_name']}**")
                st.caption(
                    f"Size: {doc['file_size_label']} | Pages: {doc['page_count']} | "
                    f"Chunks: {doc['chunk_count']} | Vectors: {doc['vectors_stored']} | "
                    f"Status: ✅ {doc['status']} | Uploaded: {doc['uploaded_at']}"
                )
            with top_cols[1]:
                if st.button("🔍 Inspect Chunks", key=f"inspect_{doc['document_id']}", use_container_width=True):
                    current = st.session_state.get("inspect_doc_id")
                    st.session_state.inspect_doc_id = None if current == doc["document_id"] else doc["document_id"]
            with top_cols[2]:
                if st.button("🔄 Reprocess", key=f"reproc_{doc['document_id']}", use_container_width=True):
                    try:
                        with st.spinner(f"Reprocessing {doc['file_name']}..."):
                            rep = pipeline.reprocess_document(
                                doc["document_id"],
                                chunk_size=chunk_size,
                                chunk_overlap=chunk_overlap,
                            )
                        st.session_state.last_ingestion_report = rep
                        st.success(f"Reprocessed '{doc['file_name']}' ({rep['chunk_count']} chunks).")
                        st.rerun()
                    except Exception as exc:
                        st.error(f"Reprocess failed: {exc}")
            with top_cols[3]:
                if st.button("🗑️ Delete", key=f"del_{doc['document_id']}", use_container_width=True):
                    try:
                        name = pipeline.delete_document(doc["document_id"])
                        if st.session_state.get("inspect_doc_id") == doc["document_id"]:
                            st.session_state.inspect_doc_id = None
                        st.success(f"Deleted '{name}' and its vectors from ChromaDB.")
                        st.rerun()
                    except Exception as exc:
                        st.error(f"Delete failed: {exc}")

            # Chunk Inspector Drawer
            if st.session_state.get("inspect_doc_id") == doc["document_id"]:
                chunks = vector_store.get_chunks_by_document_id(doc["document_id"])
                st.markdown(f"**Showing {len(chunks)} stored chunks for `{doc['file_name']}`:**")
                for c in chunks:
                    idx = c["metadata"].get("chunk_index", 0)
                    with st.expander(f"Chunk #{idx + 1} ({len(c['text'])} chars) — ID: `{c['chunk_id']}`"):
                        st.text(c["text"])
                        st.json(c["metadata"])

